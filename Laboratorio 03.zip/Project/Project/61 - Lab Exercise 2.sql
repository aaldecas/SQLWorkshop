---------------------------------------------------------------------
-- LABORATORIO 04
--
-- Ejercicio 2
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
--
-- Ejecute la consulta exactamente como est� escrita dentro de una ventana de consulta y observe el resultado.
--
-- Recibes un error. �Cu�l es el mensaje de error? �Por qu� crees que tienes este error?
---------------------------------------------------------------------

SELECT 
	custid, contactname, orderid
FROM Sales.Customers  
INNER JOIN Sales.Orders ON Customers.custid = Orders.custid;




---------------------------------------------------------------------
-- Tarea 2
--
-- Tenga en cuenta que hay nombres completos de tablas de origen escritos como alias de tabla.
--
-- Aplique los cambios necesarios a la instrucci�n SELECT para que se ejecute sin errores. Pruebe los cambios ejecutando la instrucci�n T-SQL.
--

---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 3
--
-- Copie la instrucci�n T-SQL de la tarea 2 y modif�quela para usar los alias de tabla "C" para la tabla Sales.Custumers y "O" para la tabla Sales.Orders.
--
-- Ejecute la declaraci�n escrita y compare los resultados con los resultados de la tarea 2.
--
-- Cambie el prefijo de las columnas en la declaraci�n SELECT con los nombres completos de la tabla fuente y ejecute la declaraci�n.
--
-- Recibes un error. �Por qu�?
--
-- Cambie la declaraci�n SELECT para usar los alias de tabla escritos al principio de la tarea.
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 4
--
-- Copie la instrucci�n T-SQL de la tarea 3 y modif�quela para incluir tres columnas adicionales de la tabla Sales.OrderDetails: productid, qty y unitprice.
--
-- Ejecute la declaraci�n escrita.
---------------------------------------------------------------------


