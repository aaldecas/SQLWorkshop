---------------------------------------------------------------------
-- LABORATORIO 04
--
-- Ejercicio 5
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
--
-- Ejecute el c�digo T-SQL en la Tarea 1. No se preocupe si no comprende el c�digo T-SQL provisto, ya que se usa aqu� para proporcionar un ejemplo m�s realista para una uni�n cruzada en la siguiente tarea.
---------------------------------------------------------------------
SET NOCOUNT ON;

IF OBJECT_ID('HR.Calendar') IS NOT NULL 
	DROP TABLE HR.Calendar;

CREATE TABLE HR.Calendar (
	calendardate DATE CONSTRAINT PK_Calendar PRIMARY KEY
);

DECLARE 
	@startdate DATE = DATEFROMPARTS(YEAR(SYSDATETIME()), 1, 1),
	@enddate DATE = DATEFROMPARTS(YEAR(SYSDATETIME()), 12, 31);

WHILE @startdate <= @enddate
BEGIN
	INSERT INTO HR.Calendar (calendardate)
	VALUES (@startdate);

	SET @startdate = DATEADD(DAY, 1, @startdate);
END;

SET NOCOUNT OFF;

GO
-- observe the HR.Calendar table
SELECT 
	calendardate
FROM HR.Calendar;

---------------------------------------------------------------------
-- Tarea 2
--
-- Escriba una instrucci�n SELECT para recuperar las columnas empid, firstname y lastname de la tabla HR.Employees y la columna calendardate de la tabla HR.Calendar.
--
-- Ejecute la declaraci�n escrita.
--
-- �Cu�l es el n�mero de filas devueltas por la consulta? Hay nueve filas en la tabla HR.Employees. Intente calcular el n�mero total de filas en la tabla HR.Calendar.
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Tarea 3
--
-- Ejecute la instrucci�n T-SQL proporcionada para eliminar la tabla HR.Calendar.
---------------------------------------------------------------------

IF OBJECT_ID('HR.Calendar') IS NOT NULL 
	DROP TABLE HR.Calendar;

