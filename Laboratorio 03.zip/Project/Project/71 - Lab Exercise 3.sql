---------------------------------------------------------------------
-- LABORATORIO 04
--
-- Ejercicio 3
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Para comprender mejor las tareas necesarias, primero escribir� una instrucci�n SELECT en la tabla HR.Employees que muestre las columnas empid, lastname, firstname, title y mgrid.
--
-- Ejecute la declaraci�n escrita.
-- Observe los valores en la columna mgrid. La columna mgrid est� en relaci�n con la columna empid. Esto se llama una relaci�n autorreferencial.
---------------------------------------------------------------------





---------------------------------------------------------------------
-- Tarea 2
--
-- Copie la declaraci�n SELECT de la tarea 1 y modif�quela para incluir columnas adicionales para la informaci�n del administrador (apellido, nombre) mediante una autocombinaci�n. Asigne los alias mgrlastname y mgrfirstname, respectivamente, para distinguir los nombres de los gerentes de los nombres de los empleados.
--
-- Ejecute la declaraci�n escrita. Observe el n�mero de filas devueltas.
--
-- �Es obligatorio usar alias de tabla al escribir una declaraci�n con una autocombinaci�n? �Puede usar un nombre de tabla de origen completo como alias? Por favor explique.
--
-- �Por qu� obtuvo menos filas en la instrucci�n T-SQL en la tarea 2 en comparaci�n con la tarea 1?
---------------------------------------------------------------------


