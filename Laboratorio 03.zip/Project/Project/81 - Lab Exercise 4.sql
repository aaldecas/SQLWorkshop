---------------------------------------------------------------------
-- LABORATORIO 04
--
-- Ejercicio 4
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
--
-- Escriba una instrucci�n SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers y la columna orderid de la tabla Sales.Orders. La declaraci�n debe recuperar todas las filas de la tabla Sales.Customers.
--
-- Ejecute la declaraci�n escrita.
--
-- Observe los valores en la columna orderid. �Hay alg�n valor faltante (marcado como NULL)? �Por qu�?
---------------------------------------------------------------------






