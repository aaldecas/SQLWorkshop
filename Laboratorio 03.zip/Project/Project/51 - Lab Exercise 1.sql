---------------------------------------------------------------------
-- LABORATORIO 04
--
-- Ejercicio 1
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
-- Tarea 1
--
-- Escriba una declaraci�n SELECT que devolver� la columna de nombre de producto de la tabla Production.Products (use el alias de tabla "p") y la columna de nombre de categor�a de la tabla Production.Categories (use el alias de tabla "c") usando una combinaci�n interna.
--
-- Ejecute la declaraci�n escrita.
--
-- �Qu� columna especific� como predicado en la cl�usula ON de la uni�n? �Por qu�?
--
-- Digamos que hay una nueva fila en la tabla Production.Categories y esta nueva categor�a de producto no tiene ning�n producto asociado en la tabla Production.Products. �Se incluir�a esta fila en el resultado de la declaraci�n SELECT escrita en la tarea 1? Por favor explique.
---------------------------------------------------------------------


