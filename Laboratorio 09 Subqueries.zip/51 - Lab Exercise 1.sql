---------------------------------------------------------------------
-- LAB 10
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una instrucci�n SELECT para devolver la cantidad m�xima de datos de pedidos de la tabla Ventas.Pedidos.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una instrucci�n SELECT para devolver las columnas orderid, orderdate, empid y custid de la tabla Sales.Orders. Filtre los resultados para incluir solo los pedidos en los que el orden de la fecha sea igual a la fecha del �ltimo pedido. (Sugerencia: use la consulta en la tarea 1 como una subconsulta independiente).
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 3
--
-- El departamento de TI ha escrito una declaraci�n T-SQL que recupera los pedidos de todos los clientes cuyo nombre de contacto comienza con una letra I:
--
-- Ejecutar la consulta y observar el resultado.
--
-- Modifique la consulta para filtrar clientes cuyo nombre de contacto comience con una letra B.
--
-- Ejecutar la consulta. �Qu� sucedi�? �Cu�l es el mensaje de error? �Por qu� fall� la consulta?
--
-- Aplique los cambios necesarios a la instrucci�n T-SQL para que se ejecute sin errores.
--
-------------------------------------------------- -------------------
SELECT
	orderid, orderdate, empid, custid
FROM Sales.Orders
WHERE 
	custid = 
	(
		SELECT custid
		FROM Sales.Customers
		WHERE contactname LIKE N'I%'
	);


-------------------------------------------------- -------------------
-- Tarea 4
--
-- Escriba una instrucci�n SELECT para recuperar la columna orderid de la tabla Sales.Orders y las siguientes columnas calculadas:
-- totalsalesamount (basado en las columnas qty y unitprice en la tabla Sales.OrderDetails)
-- salespctoftotal (porcentaje del monto total de ventas de cada pedido dividido por el monto total de ventas de todos los pedidos en un per�odo espec�fico)
--
-- Filtre los resultados para incluir solo los pedidos realizados en mayo de 2008.
--
-------------------------------------------------- -------------------
