---------------------------------------------------------------------
-- LAB 10
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO
-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una instrucci�n SELECT para recuperar las columnas productid y productname de la tabla Production.Products. Filtre los resultados para incluir solo los productos que se vendieron en grandes cantidades (m�s de 100 productos) para una l�nea de pedido espec�fica.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una declaraci�n SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers. Filtre los resultados para incluir solo aquellos clientes que no tienen ning�n pedido realizado.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 3
--
-- El departamento de TI ha escrito una instrucci�n T-SQL que inserta una fila adicional en la tabla Sales.Orders. Esta fila tiene un NULL en la columna custid.
--
-- Ejecute esta consulta exactamente como est� escrita dentro de una ventana de consulta.
--
-- Copie la instrucci�n T-SQL que escribi� en la tarea 2 y ejec�tela.
--
-- Observar el resultado. �Cu�ntas filas hay en el resultado? �Por qu�?
--
-- Modifique la instrucci�n T-SQL para recuperar la misma cantidad de filas que en la tarea 2. (Sugerencia: debe eliminar las filas con un valor desconocido en la columna custid).
--
-------------------------------------------------- -------------------
INSERT INTO Sales.Orders (
custid, empid, orderdate, requireddate, shippeddate, shipperid, freight, 
shipname, shipaddress, shipcity, shipregion, shippostalcode, shipcountry)
VALUES
(NULL, 1, '20111231', '20111231', '20111231', 1, 0, 
'ShipOne', 'ShipAddress', 'ShipCity', 'RA', '1000', 'USA');

GO

