---------------------------------------------------------------------
-- LAB 10
--
-- Exercise 3
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una declaraci�n SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers. Agregue una columna calculada denominada lastorderdate que contenga la fecha del �ltimo pedido de la tabla Sales.Orders para cada cliente. (Sugerencia: debe usar una subconsulta correlacionada).
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una declaraci�n SELECT para recuperar todos los clientes que no tienen ning�n pedido en la tabla Ventas.Pedidos, similar a la solicitud del ejercicio 2, tarea 3. Sin embargo, esta vez use el predicado EXISTS para filtrar los resultados e incluir solo aquellos Clientes sin pedido. Adem�s, no necesita verificar expl�citamente que la columna custid en la tabla Sales.Orders no sea NULL.
--
--
-- �Por qu� no necesitabas comprobar si hay un NULL?
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 3
--
-- Escriba una declaraci�n SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers. Filtre los resultados para incluir solo a los clientes que realizaron un pedido a partir del 1 de abril de 2008 y ordenaron un producto con un precio superior a $100.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 4
--
-- Los agregados en ejecuci�n son agregados que acumulan valores a lo largo del tiempo. Escriba una declaraci�n SELECT para recuperar la siguiente informaci�n para cada a�o:
-- El a�o del pedido
-- El monto total de las ventas
-- La cantidad total acumulada de ventas a lo largo de los a�os. Es decir, para cada a�o, devolver la suma de las ventas hasta ese a�o. Entonces, por ejemplo, para el primer a�o (2006) devuelva el monto total de las ventas, para el pr�ximo a�o (2007), devuelva la suma del monto total de las ventas del a�o anterior y el a�o 2007.
-- La instrucci�n SELECT debe tener tres columnas calculadas:
-- orderyear, que representa el a�o del pedido. Esta columna debe basarse en la columna orderyear de la tabla Sales.Orders.
-- totalsales, que representa la cantidad total de ventas de cada a�o. Esta columna debe basarse en las columnas cantidad y precio unitario de la tabla Sales.OrderDetails.
-- runales, que representa el monto de las ventas corrientes. Esta columna debe usar la subconsulta correlacionada.
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 5
--
-- Elimine la fila agregada en el ejercicio 2 utilizando la instrucci�n SQL proporcionada. Ejecute esta consulta exactamente como est� escrita dentro de una ventana de consulta.
-------------------------------------------------- -------------------
DELETE Sales.Orders
WHERE custid IS NULL;


