---------------------------------------------------------------------
-- LAB 02
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO

-- Escriba un script para crear el esquema de DirectMarketing.
--
-- Establezca la autorizaci�n a dbo.

