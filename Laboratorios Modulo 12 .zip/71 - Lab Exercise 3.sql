---------------------------------------------------------------------
-- LAB 15
--
-- Exercise 3
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado sys.sp_help sin un par�metro.
--
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado sys.sp_help para una tabla espec�fica pasando el par�metro Sales.Customers.
--
---------------------------------------------------------------------




-- Tarea 2
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado sys.sp_helptext, pasando el procedimiento almacenado Sales.GetTopCustomers como par�metro.
---------------------------------------------------------------------




-- Tarea 3
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado sys.sp_columns para la tabla Sales.Customers. Deber� pasar dos par�metros: @table_name y @table_owner.
--
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 4
--
-- Ejecute la instrucci�n T-SQL proporcionada para eliminar el procedimiento almacenado Sales.GetTopCustomers.
---------------------------------------------------------------------

DROP PROCEDURE Sales.GetTopCustomers;