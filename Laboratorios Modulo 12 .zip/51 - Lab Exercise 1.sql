---------------------------------------------------------------------
-- LAB 15
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-------------------------------------------------- -------------------
-- Tarea 1
--
-- Ejecute el c�digo T-SQL proporcionado para crear el procedimiento almacenado Sales.GetTopCustomers.
--
-- Escriba una declaraci�n T-SQL para ejecutar el procedimiento creado.
--
---------------------------------------------------------------------

CREATE PROCEDURE Sales.GetTopCustomers AS
SELECT TOP(10)
	c.custid,
	c.contactname,
	SUM(o.val) AS salesvalue
FROM Sales.OrderValues AS o
INNER JOIN Sales.Customers AS c ON c.custid = o.custid
GROUP BY c.custid, c.contactname
ORDER BY salesvalue DESC;

GO




---------------------------------------------------------------------
-- Tarea 2
--
-- El departamento de TI ha cambiado el procedimiento almacenado de la tarea 1 y le ha proporcionado el c�digo T-SQL para aplicar los cambios necesarios. Ejecute el c�digo T-SQL proporcionado.
--
-- Escriba una instrucci�n T-SQL para ejecutar el procedimiento almacenado modificado.
--
--
-- �Cu�l es la diferencia entre el c�digo T-SQL anterior y este?
--
-- Si algunas aplicaciones utilizan el procedimiento almacenado de la tarea 1, �seguir�n funcionando correctamente despu�s de los cambios que aplic� en la tarea 2?
---------------------------------------------------------------------

ALTER PROCEDURE Sales.GetTopCustomers AS
SELECT 
	c.custid,
	c.contactname,
	SUM(o.val) AS salesvalue
FROM Sales.OrderValues AS o
INNER JOIN Sales.Customers AS c ON c.custid = o.custid
GROUP BY c.custid, c.contactname
ORDER BY salesvalue DESC
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;

GO



