---------------------------------------------------------------------
-- LAB 15
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-------------------------------------------------- -------------------
-- Tarea 1
--
-- Ejecute el c�digo T-SQL proporcionado para modificar el procedimiento almacenado Sales.GetTopCustomers para incluir un par�metro para el a�o del pedido (@orderyear).
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers para el a�o 2007.
--
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers para el a�o 2008.
--
--
-- Escriba una declaraci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers sin un par�metro.
--
-- Ejecutar la instrucci�n T-SQL. �Qu� sucedi�? �Cu�l es el mensaje de error?
--
-- Si una aplicaci�n fue dise�ada para usar la versi�n del ejercicio 1 del procedimiento almacenado, �la modificaci�n realizada al procedimiento almacenado en este ejercicio afectar�a la usabilidad de esa aplicaci�n? Por favor explique.
---------------------------------------------------------------------

ALTER PROCEDURE Sales.GetTopCustomers 
	@orderyear int
AS
SELECT
	c.custid,
	c.contactname,
	SUM(o.val) AS salesvalue
FROM Sales.OrderValues AS o
INNER JOIN Sales.Customers AS c ON c.custid = o.custid
WHERE YEAR(o.orderdate) = @orderyear
GROUP BY c.custid, c.contactname
ORDER BY salesvalue DESC
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;

GO



---------------------------------------------------------------------
-------------------------------------------------- -------------------
-- Tarea 2
--
-- Ejecute el c�digo T-SQL proporcionado para modificar el procedimiento almacenado Sales.GetTopCustomers:
--
-- Escriba una declaraci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers sin un par�metro.
--
--
-- Si se dise�� una aplicaci�n para usar la versi�n del ejercicio 1 del procedimiento almacenado, �el cambio realizado en el procedimiento almacenado en esta tarea afectar�a la usabilidad de esa aplicaci�n? �C�mo influye este cambio en el dise�o de futuras aplicaciones?
---------------------------------------------------------------------

ALTER PROCEDURE Sales.GetTopCustomers 
	@orderyear int = NULL
AS
SELECT
	c.custid,
	c.contactname,
	SUM(o.val) AS salesvalue
FROM Sales.OrderValues AS o
INNER JOIN Sales.Customers AS c ON c.custid = o.custid
WHERE YEAR(o.orderdate) = @orderyear OR @orderyear IS NULL
GROUP BY c.custid, c.contactname
ORDER BY salesvalue DESC
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;

GO




---------------------------------------------------------------------
-- Tarea 3
--
-- Ejecute el c�digo T-SQL provisto para agregar el par�metro @n al procedimiento almacenado Sales.GetTopCustomers. Utilice este par�metro para especificar cu�ntos clientes desea recuperar. El valor predeterminado es 10.
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers sin ning�n par�metro.
--
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers para el a�o de pedido 2008 y cinco clientes.
--
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers para el a�o de pedido 2007.
--
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers para recuperar 20 clientes.
--
--
-- �Es necesario cambiar las aplicaciones que usan el procedimiento almacenado porque se agreg� otro par�metro?
---------------------------------------------------------------------

ALTER PROCEDURE Sales.GetTopCustomers 
	@orderyear int = NULL,
	@n int = 10
AS
SELECT
	c.custid,
	c.contactname,
	SUM(o.val) AS salesvalue
FROM Sales.OrderValues AS o
INNER JOIN Sales.Customers AS c ON c.custid = o.custid
WHERE YEAR(o.orderdate) = @orderyear OR @orderyear IS NULL
GROUP BY c.custid, c.contactname
ORDER BY salesvalue DESC
OFFSET 0 ROWS FETCH NEXT @n ROWS ONLY;

GO


-------------------------------------------------- -------------------
-- Tarea 4
--
-- Ejecute el c�digo T-SQL proporcionado para modificar el procedimiento almacenado Sales.GetTopCustomers para devolver el nombre de contacto del cliente en funci�n de una posici�n espec�fica en una clasificaci�n de ventas totales, que proporciona el par�metro @customerpos. El procedimiento tambi�n incluye un nuevo par�metro llamado @customername, que tiene una opci�n de salida.
--
-- El departamento de TI tambi�n le proporcion� el c�digo T-SQL para declarar la nueva variable @outcustomername. Utilizar� esta variable como un par�metro de salida para el procedimiento almacenado.
-- DECLARAR @outcustomername nvarchar(30);
--
-- Escriba una instrucci�n EXECUTE para invocar el procedimiento almacenado Sales.GetTopCustomers y recuperar el primer cliente.
--
-- Escriba una instrucci�n SELECT para recuperar el valor del par�metro de salida @outcustomername.
--
-- Ejecutar el lote de c�digo T-SQL que consta de la instrucci�n DECLARE proporcionada, la instrucci�n EXECUTE escrita y la instrucci�n SELECT escrita.
--
-------------------------------------------------- -------------------

ALTER PROCEDURE Sales.GetTopCustomers 
	@customerpos int = 1,
	@customername nvarchar(30) OUTPUT
AS
SET @customername = (
	SELECT
		c.contactname
	FROM Sales.OrderValues AS o
	INNER JOIN Sales.Customers AS c ON c.custid = o.custid
	GROUP BY c.custid, c.contactname
	ORDER BY SUM(o.val) DESC
	OFFSET @customerpos - 1 ROWS FETCH NEXT 1 ROW ONLY
);

GO

DECLARE @outcustomername nvarchar(30);


