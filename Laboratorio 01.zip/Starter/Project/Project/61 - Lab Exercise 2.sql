---------------------------------------------------------------------
-- Modulo 02
--
-- Ejercicio 2
---------------------------------------------------------------------

--USE TSQL;
--GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Cierre todos los archivos de secuencias de comandos abiertos.
-- Abra el script T-SQL 61 - Ejercicio de laboratorio 2.sql. Ejecutar todo el script.
-- Recibes un error. �Cu�l es el mensaje de error? �Por qu� crees que tienes este error?
---------------------------------------------------------------------

SELECT  firstname
		,lastname
		,city
		,country
FROM	HR.Employees
WHERE	country = 'USA';

---------------------------------------------------------------------
-- Tarea 2
--
-- Aplique los cambios necesarios al script para que se ejecute sin
-- un error. (Sugerencia: la declaraci�n SELECT no es el problema. Mire
-- lo que est� seleccionado en el cuadro Bases de datos disponibles). Probar los cambios
-- mediante la ejecuci�n de todo el script.
-- Observar el resultado. Observe que el resultado tiene menos filas que el
-- resultado en el ejercicio 1, tarea 2.
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 3
--
-- Como aprendi� en el M�dulo 2, se pueden escribir comentarios en scripts T-SQL
-- dentro de la l�nea especificando --. El texto despu�s de los dos guiones se
-- ser ignorado por SQL Server. Tambi�n puede especificar un comentario como un bloque.
-- comenzando con /* y terminando con */. El texto intermedio se trata como
-- un comentario de bloque y SQL Server lo ignora.
--
-- Descomente el USE TSQL; declaraci�n.
--
-- Guarde y cierre el script T-SQL. Abra el script T-SQL: script 61 - Lab Exercise 2.sql
-- de nuevo. Ejecutar todo el script. �Por qu� el script se ejecut� sin errores?
--
-- Observe el resultado y observe el contexto de la base de datos en el cuadro Bases de datos disponibles.
---------------------------------------------------------------------
