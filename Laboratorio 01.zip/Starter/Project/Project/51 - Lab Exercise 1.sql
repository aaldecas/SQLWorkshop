---------------------------------------------------------------------
-- Module 02
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Usando SQL Server Management Studio (SSMS), con�ctese a su instancia usando
-- Autenticaci�n de Windows.
--
-- Abra el Script:  T-SQL script 51 - Lab Exercise 1.sql.
-------------------------------------------------- -------------------

-------------------------------------------------- -------------------
-- Tarea 2
--
-- Ejecute el script haciendo clic en Ejecutar en la barra de herramientas (o presione F5 en el teclado).
-- Esto ejecutar� todo el script.
--
-- Observar el resultado y el contexto de la base de datos.
--
-- �Qu� base de datos est� seleccionada en el cuadro Bases de datos disponibles?
---------------------------------------------------------------------

SELECT  firstname
		,lastname
		,city
		,CountryRegionName
FROM HumanResources.vEmployee


---------------------------------------------------------------------
-- Tarea 3
--
-- Resalte la declaraci�n SELECT en el script T-SQL debajo de la tarea 2
-- descripci�n y haga clic en Ejecutar.
--
-- Observar el resultado. Deber�a obtener el mismo resultado que en la tarea 2.
--
-- Sugerencia: una forma de resaltar una parte del c�digo es mantener presionada la tecla Alt
-- mientras dibuja un rect�ngulo a su alrededor con el mouse. El c�digo dentro
-- el rect�ngulo dibujado ser� seleccionado. Intentalo.
---------------------------------------------------------------------
