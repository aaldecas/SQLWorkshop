---------------------------------------------------------------------
-- M�dulo 02
--
-- Ejercicio 3
---------------------------------------------------------------------

--USE TSQL;
--GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Observar los resultados. �Por qu� la ventana de resultados est� vac�a?
---------------------------------------------------------------------

/*
SELECT	firstname
		,lastname
		,city
		,country
FROM	HR.Employees
WHERE	country = 'USA'
ORDER BY lastname;
*/

---------------------------------------------------------------------
-- Tarea 2
--
-- Observe que antes de la instrucci�n USE est�n los caracteres
-- lo que significa que la instrucci�n USE se trata como un comentario. Ah�
-- tambi�n es un comentario de bloque alrededor de toda la declaraci�n SELECT de T-SQL.
--
-- Descomente ambas afirmaciones.
--
-- Primero ejecute la instrucci�n USE y luego ejecute la instrucci�n
-- comenzando con la cl�usula SELECT. Observa los resultados. Darse cuenta de
-- los resultados tienen las mismas filas que en el ejercicio 1, tarea 2, pero
-- est�n ordenados por la columna del apellido.
---------------------------------------------------------------------
