---------------------------------------------------------------------
-- LAB 05
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
--
-- Escriba una sentencia SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers y las columnas orderid y orderdate de la tabla Sales.Orders. 
-- Filtre los resultados para incluir solo los pedidos realizados a partir del 1 de abril de 2008 (filtre la columna de fecha de pedido). A continuaci�n, ordene el resultado por fecha de pedido en orden descendente y custid en orden ascendente.
--

---------------------------------------------------------------------


---------------------------------------------------------------------
-- Task 2
-- 
-- Ejecute la consulta exactamente como est� escrita dentro de una ventana de consulta y observe el resultado.
--
-- Recibes un error. �Cu�l es el mensaje de error? �Por qu� crees que tienes este error? (Sugerencia: recuerde el orden de procesamiento l�gico de la consulta).
--
-- Aplique los cambios necesarios a la instrucci�n SELECT para que se ejecute sin errores. Pruebe los cambios ejecutando la instrucci�n T-SQL.
--

---------------------------------------------------------------------

SELECT
	e.empid, e.lastname, e.firstname, e.title, e.mgrid,
	m.lastname AS mgrlastname, m.firstname AS mgrfirstname
FROM HR.Employees AS e
INNER JOIN HR.Employees AS m ON e.mgrid = m.empid
WHERE
	mgrlastname = N'Buck';

---------------------------------------------------------------------
-- Task 3
-- 
-- Copie la declaraci�n T-SQL existente de la tarea 2 y modif�quela para que el resultado devuelva todos los empleados y se ordene por el nombre del gerente. Intente primero usar el nombre de la columna de origen y luego intente usar el nombre de la columna de alias.
--

--
-- �Por qu� pudo usar un nombre de columna de origen o un nombre de columna de alias?
---------------------------------------------------------------------
