---------------------------------------------------------------------
-- LAB 05
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------

-- Tarea 1
--
-- Escriba una instrucci�n SELECT que devuelva las columnas custid, companyname, contactname, address, city, country y phone de la tabla Sales.Customers. Filtre los resultados para incluir solo los clientes del pa�s Brasil.
--
--

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 2
-- 
-- Escriba una instrucci�n SELECT que devuelva las columnas custid, companyname, contactname, address, city, country y phone de la tabla Sales.Customers. Filtre los resultados para incluir solo clientes de los pa�ses 
-- Brasil, UK y USA.
--

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 3
-- 
-- Escriba una instrucci�n SELECT que devuelva las columnas custid, companyname, contactname, address, city, country y phone de la tabla Sales.Customers. Filtre los resultados para incluir solo los clientes con un nombre de contacto que comience con la letra A.
--
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 4
-- 
-- El departamento de TI ha escrito una instrucci�n T-SQL que recupera las columnas custid y companyname de la tabla Sales.Customers y la columna orderid de la tabla Sales.Orders.
--
-- Ejecutar la consulta. F�jate en dos cosas. Primero, la consulta recupera todas las filas de la tabla Sales.Customers. En segundo lugar, hay un operador de comparaci�n en la cl�usula ON que especifica que la columna de la ciudad debe ser igual al valor "Par�s".
--
-- Copie la instrucci�n T-SQL proporcionada y modif�quela para que tenga un operador de comparaci�n para la columna de la ciudad en la cl�usula WHERE. Ejecutar la consulta.
--
-- �El resultado es el mismo que en la primera instrucci�n T-SQL? �Por qu�? �Cu�l es la diferencia entre especificar el predicado en la cl�usula ON y en la cl�usula WHERE?
---------------------------------------------------------------------

SELECT
	c.custid, c.companyname, o.orderid
FROM Sales.Customers AS c
LEFT OUTER JOIN Sales.Orders AS o ON c.custid = o.custid AND c.city = 'Paris';


---------------------------------------------------------------------
-- Task 5
-- 
-- Escriba una instrucci�n T-SQL para recuperar clientes de la tabla Sales.Customers que no tengan pedidos coincidentes en la tabla Sales.Orders. 
-- La coincidencia de clientes con pedidos se basa en una comparaci�n entre el Id del cliente y el valor de Id del pedido. 
-- Recupere las columnas custid y companyname de la tabla Sales.Customers. (Sugerencia: use una instrucci�n T-SQL que sea similar a la de la tarea anterior).
--

---------------------------------------------------------------------

