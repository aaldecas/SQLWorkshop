---------------------------------------------------------------------
-- LAB 05
--
-- Exercise 3
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
-- 
-- Escriba una declaraci�n SELECT en la tabla Sales.Orders y recupere las columnas orderid y orderdate. Recupere los �ltimos 20 pedidos, en funci�n de la fecha de pedido.
--

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 2
-- 
-- Escriba una instrucci�n SELECT para recuperar el mismo resultado que en la tarea 1, pero use la cl�usula OFFSET-FETCH.
--

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 3
-- 
-- Escriba una declaraci�n SELECT para recuperar las columnas productname y unitprice de la tabla Production.Products.
--
-- Ejecute la instrucci�n T-SQL y observe el n�mero de filas devueltas.
--
-- Modifique la declaraci�n SELECT para incluir solo el 10 por ciento superior de los productos seg�n el pedido de precio unitario.
--

--
-- �Es posible implementar esta tarea con la cl�usula OFFSET-FETCH?
---------------------------------------------------------------------


