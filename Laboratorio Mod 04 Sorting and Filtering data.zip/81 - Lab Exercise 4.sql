---------------------------------------------------------------------
-- LAB 05
--
-- Exercise 4
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
--
-- Escriba una sentencia SELECT para recuperar las columnas custid, orderid y orderdate de la tabla Sales.Orders. Ordene las filas por fecha de pedido e ID de pedido. Recuperar las primeras 20 filas.
--

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 2
-- 
-- Copie la declaraci�n SELECT en la tarea 1 y modifique la cl�usula OFFSET-FETCH para omitir las primeras 20 filas y obtener las siguientes 20 filas.
--

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 3
-- 
-- Se le proporcionan los par�metros @pagenum para el n�mero de p�gina solicitado y @pagesize para el tama�o de p�gina solicitado. �Puede averiguar c�mo escribir una forma gen�rica de la cl�usula OFFSET-FETCH usando esos par�metros?
-- (No se preocupe por no estar familiarizado con esos par�metros todav�a).
---------------------------------------------------------------------