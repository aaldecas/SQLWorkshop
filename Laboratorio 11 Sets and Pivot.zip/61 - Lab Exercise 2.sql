---------------------------------------------------------------------
-- LAB 12
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Escriba una instrucci�n SELECT para recuperar las columnas productid y productname de la tabla Production.Products. Adem�s, para cada producto, recupere las dos �ltimas filas de la tabla Sales.OrderDetails seg�n el n�mero de ID de pedido.
--
-- Utilice el operador CROSS APPLY y una subconsulta correlacionada. Ordene el resultado por la columna productid.
--
---------------------------------------------------------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Ejecute el c�digo T-SQL provisto para crear la funci�n con valores de tabla en l�nea fnGetTop3ProductsForCustomer, como lo hizo en el m�dulo anterior:
--
-- Escriba una declaraci�n SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers. Utilice el operador CROSS APPLY con la funci�n dbo.fnGetTop3ProductsForCustomer para recuperar las columnas productid, productname y totalsalesamount para cada cliente.
--
---------------------------------------------------------------------
IF OBJECT_ID('dbo.fnGetTop3ProductsForCustomer') IS NOT NULL
	DROP FUNCTION dbo.fnGetTop3ProductsForCustomer;

GO

CREATE FUNCTION dbo.fnGetTop3ProductsForCustomer
(@custid AS INT) RETURNS TABLE
AS
RETURN
SELECT TOP(3)
	d.productid, 
	MAX(p.productname) AS productname, 
	SUM(d.qty * d.unitprice) AS totalsalesamount	
FROM Sales.Orders AS o
INNER JOIN Sales.OrderDetails AS d ON d.orderid = o.orderid
INNER JOIN Production.Products AS p ON p.productid = d.productid
WHERE custid = @custid
GROUP BY d.productid
ORDER BY totalsalesamount DESC;

GO


---------------------------------------------------------------------
-- Tarea 3
--
-- Copie la sentencia T-SQL de la tarea anterior y modif�quela reemplazando el operador CROSS APPLY por el operador OUTER APPLY.
--
---------------------------------------------------------------------



-------------------------------------------------- -------------------
-- Tarea 4
--
-- Copie la instrucci�n T-SQL de la tarea anterior y modif�quela filtrando los resultados para mostrar solo los clientes sin productos. (Sugerencia: en una cl�usula WHERE, busque cualquier columna devuelta por la funci�n con valores de tabla en l�nea que sea NULL).
--
--
-- �Cu�l es la diferencia entre los operadores CROSS APPLY y OUTER APPLY?
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Tarea 5
--
-- Elimine la funci�n con valores de tabla en l�nea creada ejecutando el c�digo T-SQL proporcionado:
--
-- Ejecute este c�digo exactamente como est� escrito dentro de una ventana de consulta.
---------------------------------------------------------------------

IF OBJECT_ID('dbo.fnGetTop3ProductsForCustomer') IS NOT NULL
	DROP FUNCTION dbo.fnGetTop3ProductsForCustomer;


