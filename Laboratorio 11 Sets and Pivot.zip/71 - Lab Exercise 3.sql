---------------------------------------------------------------------
-- LAB 12
--
-- Exercise 3
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una sentencia SELECT para recuperar la columna custid de la tabla Sales.Orders. Filtre los resultados para incluir solo a los clientes que compraron m�s de 20 productos diferentes (seg�n la columna productid de la tabla Sales.OrderDetails).
--
---------------------------------------------------------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una sentencia SELECT para recuperar la columna custid de la tabla Sales.Orders. Filtre los resultados para incluir solo clientes del pa�s EE. UU. y excluya a todos los clientes del resultado anterior (tarea 1). (Sugerencia: use el operador EXCEPTO y la consulta anterior).
--
---------------------------------------------------------------------




-- Tarea 3
--
-- Escriba una sentencia SELECT para recuperar la columna custid de la tabla Sales.Orders. Filtre solo los clientes que tengan un valor total de ventas superior a $10,000. Calcule el valor de las ventas usando las columnas qty y unitprice de la tabla Sales.OrderDetails.
--
---------------------------------------------------------------------



-- Tarea 4
--
-- Copie la instrucci�n T-SQL de la tarea 2. Agregue el operador INTERSECT al final de la instrucci�n. Despu�s del operador INTERSECT, agregue la instrucci�n T-SQL de la tarea 3.
--

--
-- �Puede explicar en t�rminos comerciales qu� clientes son parte del resultado?
---------------------------------------------------------------------



-- Tarea 5
--
-- Copie la declaraci�n T-SQL de la tarea anterior y agregue par�ntesis alrededor de las dos primeras declaraciones SELECT (desde el principio hasta el operador INTERSECT).
--

--
-- �Es el resultado diferente al resultado de la tarea 4? Explique por qu�.
--
-- �Cu�l es la precedencia entre los operadores de conjuntos?
---------------------------------------------------------------------

