
USE TSQL;
GO



---------------------------------------------------------------------
-- Tarea 1
--
-- Para cada cliente, escriba una declaraci�n SELECT para recuperar el monto total de ventas para cada categor�a de producto. Muestre cada categor�a de producto como una columna separada. He aqu� c�mo realizar esta tarea:
-- Cree un CTE llamado SalesByCategory para recuperar la columna custid de la tabla Sales.Orders como una columna calculada basada en las columnas qty y unitprice y la columna categoryname de la tabla Production.Categories. Filtre el resultado para incluir solo los pedidos del a�o 2008.
-- Deber� UNIRSE a las tablas Sales.Orders, Sales.OrderDetails, Production.Products y Production.Categories.
-- Escriba una declaraci�n SELECT contra el CTE que devuelva una fila para cada cliente (custid) y una columna para cada categor�a de producto, con el monto total de ventas para el cliente actual y la categor�a de producto.
-- Muestre las siguientes categor�as de productos: Bebidas, Condimentos, Dulces, [Productos l�cteos], [Granos/Cereales], [Carne/Aves], Productos agr�colas y Mariscos.
--
-- Ejecutar el c�digo T-SQL completo (el CTE y la instrucci�n SELECT).
--
---------------------------------------------------------------------

