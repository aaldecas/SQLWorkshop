﻿---------------------------------------------------------------------
-- LAB 12
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una sentencia SELECT para devolver las columnas productid y productname de la tabla Production.Products. Filtre los resultados para incluir solo productos que tengan un valor de categoría 4.
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Tarea 2
--
-- Escriba una sentencia SELECT para devolver las columnas productid y productname de la tabla Production.Products. Filtre los resultados para incluir solo productos que tengan un monto de ventas total de más de $50,000. Para conocer el monto total de las ventas, deberá consultar la tabla Sales.OrderDetails y agregar todos los valores de línea de pedido (qty * unitprice) para cada producto.
--
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Tarea 3
--
-- Escriba una declaración SELECT que use el operador UNION para recuperar las columnas productid y productname de las declaraciones T-SQL en la tarea 1 y la tarea 2.
--
--
-- ¿Cuál es el número total de filas en el resultado? Si compara este número con un valor agregado del número de filas de la tarea 1 y la tarea 2, ¿hay alguna diferencia?
--
-- Copie la instrucción T-SQL y modifíquela para usar el operador UNION ALL.
--
--
-- ¿Cuál es el número total de filas en el resultado? ¿Cuál es la diferencia entre los operadores UNION y UNION ALL?
---------------------------------------------------------------------


-- Tarea 4
--
-- Escriba una declaración SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers. Muestre los 10 clientes principales por monto de ventas de enero de 2008 y muestre los 10 clientes principales por monto de ventas de febrero de 2008 (Sugerencia: escriba dos declaraciones SELECT, cada una de las cuales une Sales.Customers y ​Sales.OrderValues y use el operador de conjunto apropiado).
--
---------------------------------------------------------------------

