USE TSQL

/***************************************************************
Task 1

Escriba una instrucci�n INSERT para agregar un registro a la tabla Empleados
con los siguientes valores:
�Title: Sales Representative
�Titleofcourtesy: Mr
�FirstName: Laurence
�Lastname: Grider
�Hiredate: 04/04/2013
�Birthdate: 10/25/1975
�Address: 1234 1st Ave. S.E.
�City: Seattle
�Country: USA
�Phone: (206)555-0105
*****************************************************************/
--Task 2

--1.	Escriba una declaraci�n de UPDATE para actualizar todos los registros en la tabla Clientes que tienen una ciudad de Berl�n y un t�tulo de contacto de Representante de ventas para tener un t�tulo de contacto de Consultor de ventas.

--  Task 2: Delete Rows
--1.Escriba una declaraci�n DELETE para eliminar todos los registros en la tabla de Clientes potenciales que tienen el nombre de contacto de 'Taylor, Maurice, 'Mallit, Ken' o 'Tiano, Mike', ya que estos registros ahora se agregaron a la tabla Clientes.
