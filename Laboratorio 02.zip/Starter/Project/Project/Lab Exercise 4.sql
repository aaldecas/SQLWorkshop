---------------------------------------------------------------------
-- LABORATORIO 03
--
-- Ejercicio 4
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
-- Escriba una declaraci�n SELECT para mostrar las columnas de ID de categor�a y nombre de producto de la tabla Production.Products.
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Tarea 2
-- Mejore la declaraci�n SELECT en la tarea 1 agregando una expresi�n CASE que genera una columna de resultado denominada nombrecategor�a. La nueva columna debe contener la traducci�n del ID de categor�a a su nombre de categor�a respectivo, seg�n la tabla de asignaci�n proporcionada anteriormente. Utilice el valor "Otro" para cualquier ID de categor�a que no se encuentre en la tabla de asignaci�n.
---------------------------------------------------------------------



---------------------------------------------------------------------
-- Tarea 3
-- Modifique la declaraci�n SELECT en la tarea 2 agregando una nueva columna llamada iscampaign. Esto mostrar� la descripci�n "Productos de la campa�a" para las categor�as Bebidas, Productos agr�colas y Mariscos y la descripci�n "Productos que no pertenecen a la campa�a" para todas las dem�s categor�as.
---------------------------------------------------------------------


