---------------------------------------------------------------------
-- LABORATORIO 03
--
-- Ejercicio 3
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Escriba una declaraci�n SELECT para devolver las columnas contactname y contacttitle de la tabla Sales.Customers, asignando "C" como el alias de la tabla. Utilice el alias C de la tabla para anteponer los nombres de las dos columnas necesarias en la lista SELECT. El beneficio de usar alias de tabla ser� m�s claro en m�dulos futuros cuando se presenten temas como uniones y subconsultas.
--
-- Ejecute la declaraci�n escrita.
---------------------------------------------------------------------




-- Tarea 2
--
-- Escriba una sentencia SELECT para devolver las columnas de nombre de contacto, cargo de contacto y nombre de empresa de la tabla Sales.Customers. Asigne a estas columnas los alias Nombre, T�tulo y Nombre de la empresa, respectivamente, para obtener t�tulos de columna m�s amigables para los humanos con fines de generaci�n de informes.
--
-- Ejecute la declaraci�n escrita
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 3
--
-- Escriba una consulta para mostrar la columna productname de la tabla Production.Products usando "P" como el alias de la tabla y "Product Name" como el alias de la columna.
--
-- Ejecute la declaraci�n escrita
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 4
--
-- Un desarrollador ha escrito una consulta para recuperar dos columnas (ciudad y regi�n) de la tabla Sales.Customers. Cuando se ejecuta la consulta, devuelve solo una columna. Su tarea es analizar la consulta, corregirla para que devuelva dos columnas y explicar por qu� la consulta solo devolvi� una columna.
--
-- Ejecute la consulta exactamente como est� escrita dentro de una ventana de consulta y observe el resultado.
--
-- Corrija la consulta para devolver las columnas de ciudad y pa�s de la tabla Sales.Customers.
--
-- �Por qu� la consulta devolvi� solo una columna? �Cu�l era el t�tulo de la columna en la salida? �Cu�l es la mejor pr�ctica cuando se usan alias para columnas para evitar tales errores?
---------------------------------------------------------------------

SELECT city country
FROM Sales.Customers;

