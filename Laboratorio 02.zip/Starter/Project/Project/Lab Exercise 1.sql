---------------------------------------------------------------------
-- LABORATORIO 03
--
-- Ejercicio 1
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Tarea 1
--
-- Usando SSMS, con�ctese a su instancia usando la autenticaci�n de Windows (si se est� conectando a una instancia local de SQL Server) o la autenticaci�n de SQL Server (si est� usando SQL Azure).
--
-- En Object Explorer, expanda la base de datos TSQL y expanda la carpeta Tables.
--
-- Eche un vistazo a los nombres de las tablas en el esquema de Ventas.
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 2
--
-- Escriba una instrucci�n SELECT que devuelva todas las filas y todas las columnas de la tabla Sales.Customers.
-- Sugerencia: puede usar la funcionalidad de arrastrar y soltar para arrastrar elementos como nombres de tablas y columnas desde el Explorador de objetos a la ventana de consulta. Escriba la misma declaraci�n SELECT usando la funcionalidad de arrastrar y soltar.
--
-- Ejecute la declaraci�n escrita
---------------------------------------------------------------------




---------------------------------------------------------------------
-- Tarea 3
--
-- Expanda la tabla Sales.Customers en el Explorador de objetos y expanda la carpeta Columnas. Observe todas las columnas de la tabla.
--
-- Escriba una instrucci�n SELECT para devolver las columnas de nombre de contacto, direcci�n, c�digo postal, ciudad y pa�s.
--
-- Ejecute la declaraci�n escrita. 
--
-- �Cu�l es el n�mero de filas afectadas por la �ltima consulta? (Sugerencia: debido a que est� emitiendo una declaraci�n SELECT en toda la tabla, el n�mero de filas ser� el mismo que el n�mero de filas para toda la tabla Sales.Customer).
---------------------------------------------------------------------

