---------------------------------------------------------------------
-- LAB 11
--
-- Exercise 4
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una declaraci�n SELECT en la vista Sales.OrderValues y recupere las columnas custid y totalsalesamount como un total de la columna val. Filtre los resultados para incluir pedidos solo para el a�o de pedido 2007.
--
--
-- Defina una funci�n con valores de tabla en l�nea utilizando el siguiente encabezado de funci�n y agregue su consulta anterior despu�s de la cl�usula RETURN.
--
-- Modifique la consulta reemplazando el valor del a�o constante 2007 en la cl�usula WHERE con el par�metro @orderyear.
--
-- Resalte el c�digo completo y ejec�telo. Esto crear� una funci�n con valores de tabla en l�nea denominada dbo.fnGetSalesByCustomer.
-------------------------------------------------- -------------------

-- instrucci�n SQL inicial
CREATE FUNCTION dbo.fnGetSalesByCustomer
(@orderyear AS INT) RETURNS TABLE
AS
RETURN
-- copy here the SQL statement


GO


-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una declaraci�n SELECT para recuperar las columnas custid y totalsalesamount de la funci�n con valores de tabla en l�nea dbo.fnGetSalesByCustomer. Utilice el valor 2007 para el par�metro necesario.
--
-------------------------------------------------- -------------------


-------------------------------------------------- -------------------
-- Tarea 3
--
-- En esta tarea, consultar� las tablas Production.Products y Sales.OrderDetails. Escriba una instrucci�n SELECT que recupere los tres productos m�s vendidos en funci�n del valor total de ventas del cliente con ID 1. Devuelva las columnas productid y productname de la tabla Production.Products. Utilice las columnas de cantidad y precio unitario de la tabla Sales.OrderDetails para calcular el valor de cada l�nea de pedido y devuelva la suma de todos los valores por producto, nombrando la columna resultante totalsalesamount. Filtre los resultados para incluir solo las filas donde el valor custid es igual a 1.
--
--
-- Cree una funci�n con valores de tabla en l�nea basada en el siguiente encabezado de funci�n, utilizando la instrucci�n SELECT anterior. Reemplace el valor constante de custid 1 en la consulta con el par�metro de entrada de la funci�n @custid:
--
-- Resalte el c�digo completo y ejec�telo. Esto crear� una funci�n con valores de tabla en l�nea llamada dbo.fnGetTop3ProductsForCustomer que excepto un par�metro para la identificaci�n del cliente.
--
-- Pruebe la funci�n con valores de tabla en l�nea creada escribiendo una declaraci�n SELECT contra ella y use el valor 1 para el par�metro de identificaci�n del cliente. Recupere las columnas productid, productname y totalsalesamount, y use el alias p para la funci�n con valores de tabla en l�nea.
--
-------------------------------------------------- -------------------
-- initial SQL statement

GO

CREATE FUNCTION dbo.fnGetTop3ProductsForCustomer
(@custid AS INT) RETURNS TABLE
AS
RETURN
-- copy here the SQL statement


GO

-- write here the SQL statement against the created function


-------------------------------------------------- -------------------
-- Tarea 4
--
-- Escriba una declaraci�n SELECT para recuperar el mismo resultado que en el ejercicio 3, tarea 3, pero use la funci�n con valores de tabla en l�nea creada en la tarea 2 (dbo.fnGetSalesByCustomer).
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 5
--
-- Elimine las funciones con valores de tabla en l�nea creadas ejecutando la instrucci�n T-SQL proporcionada. Ejecute este c�digo exactamente como est� escrito dentro de una ventana de consulta.
-------------------------------------------------- -------------------

IF OBJECT_ID('dbo.fnGetSalesByCustomer') IS NOT NULL
	DROP FUNCTION dbo.fnGetSalesByCustomer;

IF OBJECT_ID('dbo.fnGetTop3ProductsForCustomer') IS NOT NULL
	DROP FUNCTION dbo.fnGetTop3ProductsForCustomer;
GO


