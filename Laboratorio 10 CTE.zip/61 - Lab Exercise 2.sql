---------------------------------------------------------------------
-- LAB 11
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una instrucción SELECT en una tabla derivada y recupere las columnas productid y productname. Filtre los resultados para incluir solo las filas en las que el valor de la columna de tipo de precio es igual a alto. Use la declaración SELECT del ejercicio 1, tarea 4 como la consulta interna que define la tabla derivada. No olvide utilizar un alias para la tabla derivada. (Puedes usar el alias p.)
--

-------------------------------------------------- -------------------


-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una sentencia SELECT para recuperar la columna custid y dos columnas calculadas: totalsalesamount, que devuelve el total de ventas por cliente, y avgsalesamount, que devuelve el promedio de ventas de pedidos por cliente. Para calcular correctamente el importe medio de ventas de pedidos por cliente, primero deberá calcular el importe total de ventas por pedido. Puede hacerlo definiendo una tabla derivada basada en una consulta que une las tablas Sales.Orders y Sales.OrderDetails. Puede utilizar las columnas custid y orderid de la tabla Sales.Orders y las columnas qty y unitprice de la tabla Sales.OrderDetails.
--

-------------------------------------------------- -------------------


-------------------------------------------------- -------------------
-- Tarea 3
--
-- Escriba una instrucción SELECT para recuperar las siguientes columnas:
-- orderyear, que representa el año de la fecha del pedido
-- curtotalsales, que representa el monto total de ventas para el año de pedido actual
-- prevtotalsales, que representa el monto total de ventas del año de pedido anterior
-- porcentaje de crecimiento, que representa el porcentaje de crecimiento de las ventas en el año de pedido actual en comparación con el año de pedido anterior
-- Deberá escribir una declaración T-SQL utilizando dos tablas derivadas. Para obtener el año del pedido y las columnas de ventas totales para cada instrucción SELECT, puede consultar una vista ya existente denominada Sales.OrderValues. La columna val representa el monto de las ventas.
-- No olvide que el año de pedido 2006 no tiene un año de pedido anterior en la base de datos, pero aún debe ser recuperado por la consulta.


-------------------------------------------------- -------------------