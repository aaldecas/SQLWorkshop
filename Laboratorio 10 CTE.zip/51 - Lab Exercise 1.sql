---------------------------------------------------------------------
-- LAB 11
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una sentencia SELECT para devolver las columnas productid, productname, supplierid, unitprice y discontinued de la tabla Production.Products. Filtre los resultados para incluir solo los productos que pertenecen a la categor�a Bebidas (categoryid es igual a 1).
--
--
-- Modifique el c�digo T-SQL para incluir la siguiente instrucci�n T-SQL proporcionada. Ponga esta declaraci�n antes de la cl�usula SELECT:
--
-- Ejecutar la instrucci�n T-SQL completa. Esto crear� una vista de objeto denominada ProductBeverages en el esquema de producci�n.
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una instrucci�n SELECT para devolver las columnas productid y productname de la vista Production.ProductsBeverages. Filtre los resultados para incluir solo productos en los que ID de proveedor sea igual a 1.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 3
--
-- El departamento de TI ha escrito una instrucci�n T-SQL que agrega una cl�usula ORDER BY a la vista creada en la tarea 1.
--
-- Ejecutar el c�digo proporcionado. �Qu� sucedi�? �Cu�l es el mensaje de error? �Por qu� fall� la consulta?
--
-- Modifique la instrucci�n T-SQL suministrada incluyendo la opci�n TOP (100) PERCENT. La consulta deber�a verse as�:
--
-- Ejecutar la instrucci�n T-SQL modificada. Al aplicar los cambios necesarios, ha modificado la vista existente. Tenga en cuenta que todav�a est� usando la cl�usula ORDER BY.
--
-- Si escribe una consulta en la vista Production.ProductsBeverages modificada, �se garantizar� que las filas recuperadas se ordenar�n por nombre de producto? Por favor explique.
-------------------------------------------------- -------------------
ALTER VIEW Production.ProductsBeverages AS
SELECT
	productid, productname, supplierid, unitprice, discontinued
FROM Production.Products
WHERE categoryid = 1
ORDER BY productname;

GO
---------------------------------------------------------------------
-- Tarea 4
--
-- El departamento de TI ha escrito una declaraci�n T-SQL que agrega una columna calculada adicional a la vista creada en la tarea 1.
--
-- Ejecutar la consulta proporcionada. �Qu� sucedi�? �Cu�l es el mensaje de error? �Por qu� fall� la consulta?
--
-- Aplique los cambios necesarios para que la instrucci�n T-SQL se ejecute correctamente.
---------------------------------------------------------------------

ALTER VIEW Production.ProductsBeverages AS
SELECT
	productid, productname, supplierid, unitprice, discontinued,
	CASE WHEN unitprice > 100. THEN N'high' ELSE N'normal' END
FROM Production.Products
WHERE categoryid = 1;

GO

---------------------------------------------------------------------
-- Task 5
-- 
-- Elimine la vista creada ejecutando la instrucci�n T-SQL proporcionada. Ejecute este c�digo exactamente como est� escrito dentro de una ventana de consulta.---------------------------------------------------------------------

IF OBJECT_ID(N'Production.ProductsBeverages', N'V') IS NOT NULL
	DROP VIEW Production.ProductsBeverages;
