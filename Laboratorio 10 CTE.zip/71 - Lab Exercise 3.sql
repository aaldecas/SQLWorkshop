---------------------------------------------------------------------
-- LAB 11
--
-- Exercise 3
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una declaraci�n SELECT como la del ejercicio 2, tarea 1, pero use un CTE en lugar de una tabla derivada. Use alias de columna en l�nea en la consulta de CTE y asigne un nombre a ProductBeverages de CTE.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una declaraci�n SELECT contra Sales.OrderValues ??para recuperar el ID de cada cliente y el monto total de ventas para el a�o 2008. Defina un CTE llamado c2008 basado en esta consulta usando el formulario de alias externo para nombrar las columnas CTE custid y salesamt2008. Una la tabla Sales.Customers y la CTE c2008, devolviendo las columnas custid y contactname de la tabla Sales.Customers y la columna salesamt2008 de la CTE c2008.
--
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 3
--
-- Escriba una declaraci�n SELECT para recuperar las columnas custid y contactname de la tabla Sales.Customers. Tambi�n recupere las siguientes columnas calculadas:
-- salesamt2008, que representa la cantidad total de ventas del a�o 2008
-- salesamt2007, que representa la cantidad total de ventas del a�o 2007
-- porcentaje de crecimiento, que representa el porcentaje de crecimiento de las ventas entre los a�os 2007 y 2008
-- Si el crecimiento porcentual es NULL, muestra el valor 0.
--
-- Puede usar el CTE de la tarea anterior y agregar otro CTE para el a�o 2007. Luego, �nalos a ambos con la tabla Sales.Customers. Ordene el resultado por la columna de crecimiento porcentual.
--
-------------------------------------------------- -------------------