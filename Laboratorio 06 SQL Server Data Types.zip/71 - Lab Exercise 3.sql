---------------------------------------------------------------------
-- LAB 06
--
-- Exercise 3
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
--
-- Escriba una instrucci�n SELECT en la tabla Sales.Customers y recupere las columnas de nombre de contacto y ciudad. Concatene ambas columnas para que la nueva columna se vea as�:
-- Allen, Michael (ciudad: Berl�n)

---------------------------------------------------------------------


---------------------------------------------------------------------
-- Task 2
-- 
-- Copie la instrucci�n T-SQL en la tarea 1 y modif�quela para extender la columna calculada con nueva informaci�n de la columna de la regi�n. Trate un NULL en la columna de la regi�n como una cadena vac�a para fines de concatenaci�n. Cuando la regi�n es NULL, la columna modificada deber�a verse as�:
-- Allen, Michael (ciudad: Berl�n, regi�n: )
--
-- Cuando la regi�n no es NULL, la columna modificada deber�a verse as�
-- Richardson, Shawn (ciudad: Sao Paulo, regi�n: SP)
--

---------------------------------------------------------------------


---------------------------------------------------------------------
-- Task 3
-- 
-- Escriba una instrucci�n SELECT para recuperar las columnas de nombre de contacto y t�tulo de contacto de la tabla Sales.Customers. Devuelve solo las filas donde el primer car�cter del nombre del contacto es de la 'A' a la 'G'.
---------------------------------------------------------------------

