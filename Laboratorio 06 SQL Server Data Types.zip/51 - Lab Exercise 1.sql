---------------------------------------------------------------------
-- LAB 06
--
-- Exercise 1
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
-- 
-- Escriba una instrucci�n SELECT para devolver columnas que contengan:
-- La fecha y hora actual. Utilice el alias fechahoraactual.
-- S�lo la fecha actual. Utilice el alias fechaactual.
-- S�lo la hora actual. Utilice el alias horaactual.
-- S�lo el a�o en curso. Utilice el alias a�oactual.
-- S�lo el n�mero del mes actual. Utilice el alias mes actual.
-- Solo el d�a actual del n�mero del mes. Utilice el alias d�a actual.
-- S�lo el n�mero de semana actual en el a�o. Utilice el alias n�mero de la semana actual.
-- El nombre del mes actual basado en la columna currentdatetime. Utilice el alias nombremesactual.
-- 
--
-- �Puede usar el alias currentdatetime como fuente en el c�lculo de la segunda columna (currentdate)? Por favor explique.
---------------------------------------------------------------------
select 
current_timestamp as currentdatetime



---------------------------------------------------------------------
-- Task 2
--  
-- Escriba el 11 de diciembre de 2011 como una columna con un tipo de datos de fecha. Usa las diferentes posibilidades dentro del lenguaje T-SQL (cast, convert, funci�n espec�fica, etc.) y usa el alias somedate.---------------------------------------------------------------------


---------------------------------------------------------------------
-- Task 3
-- 
-- Escriba una instrucci�n SELECT para devolver columnas que contengan:
-- Tres meses a partir de la fecha y hora actual. Utilice el alias tres meses.
-- N�mero de d�as entre la fecha actual y la primera columna (tres meses). Utilice el alias diffdays.
-- N�mero de semanas entre el 4 de abril de 1992 y el 16 de septiembre de 2011. Utilice el alias diffweeks.
-- Primer d�a del mes actual basado en la fecha y hora actuales. Utilice el alias firstday.
--
---------------------------------------------------------------------


---------------------------------------------------------------------
-- Task 4
-- 
-- El departamento de TI ha escrito una instrucci�n T-SQL que crea y completa una tabla denominada Sales.Somedates.
--
-- Ejecute la instrucci�n T-SQL proporcionada.
--
-- Escriba una sentencia SELECT en la tabla Sales.Somedates y recupere la columna isitdate. Agregue una nueva columna llamada convertdate con un nuevo valor de tipo de datos de fecha basado en la columna isitdate. Si la columna isitdate no se puede convertir a un tipo de datos de fecha para una fila espec�fica, devuelva NULL.
--

--
-- �Cu�l es la diferencia entre las funciones SYSDATETIME y CURRENT_TIMESTAMP?
--
-- �Qu� es un formato independiente del idioma para el tipo DATE?
---------------------------------------------------------------------

SET NOCOUNT ON;

IF OBJECT_ID('Sales.Somedates') IS NOT NULL 
	DROP TABLE Sales.Somedates;

CREATE TABLE Sales.Somedates (
	isitdate varchar(9)
);

INSERT INTO Sales.Somedates (isitdate) VALUES 
	('20110101'),
	('20110102'),
	('20110103X'),
	('20110104'),
	('20110105'),
	('20110106'),
	('20110107Y'),
	('20110108');

SET NOCOUNT OFF;

SELECT isitdate
FROM Sales.Somedates;





---------------------------------------------------------------------
-- Task 5
-- 

---------------------------------------------------------------------
-- drop the table 

DROP TABLE Sales.Somedates;