---------------------------------------------------------------------
-- LAB 06
--
-- Exercise 4
---------------------------------------------------------------------

USE TSQL;
GO

-------------------------------------------------- -------------------
-- Tarea 1
--
-- Escriba una declaraci�n SELECT para recuperar la columna contactname de la tabla Sales.Customers. En funci�n de esta columna, agregue una columna calculada denominada apellido, que debe constar de todos los caracteres antes de la coma.
--

-------------------------------------------------- -------------------




-------------------------------------------------- -------------------
-- Tarea 2
--
-- Escriba una declaraci�n SELECT para recuperar la columna contactname de la tabla Sales.Customers y reemplace la coma en el nombre del contacto con una cadena vac�a. En funci�n de esta columna, agregue una columna calculada denominada firstname, que debe constar de todos los caracteres despu�s de la coma.
--

-------------------------------------------------- -------------------


-------------------------------------------------- -------------------
-- Tarea 3
--
-- Escriba una instrucci�n SELECT para recuperar la columna custid de la tabla Sales.Customers. Agregue una nueva columna calculada para crear una representaci�n de cadena del custid como un c�digo de cliente de ancho fijo (6 caracteres) con el prefijo C y ceros a la izquierda. Por ejemplo, el valor de custid 1 deber�a parecerse a C00001.
--
 
-------------------------------------------------- -------------------



-------------------------------------------------- -------------------
-- Tarea 4
--
-- Escriba una declaraci�n SELECT para recuperar la columna contactname de la tabla Sales.Customers. Agregue una columna calculada, que debe contar la cantidad de ocurrencias del car�cter 'a' dentro del nombre del contacto. (Sugerencia: use las funciones de cadena REPLACE y LEN.) Ordene el resultado de las filas con las ocurrencias m�s altas a las m�s bajas.
--

-------------------------------------------------- -------------------