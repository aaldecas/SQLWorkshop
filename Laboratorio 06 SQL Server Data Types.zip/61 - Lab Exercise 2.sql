---------------------------------------------------------------------
-- LAB 07
--
-- Exercise 2
---------------------------------------------------------------------

USE TSQL;
GO

---------------------------------------------------------------------
-- Task 1
-- 
-- Escriba una declaraci�n SELECT para recuperar valores distintos para la columna custid de la tabla Sales.Orders. Filtre los resultados para incluir solo los pedidos realizados en febrero de 2008.

---------------------------------------------------------------------


---------------------------------------------------------------------
-- Task 2
-- 
-- Escriba una instrucci�n SELECT con estas columnas:
-- Fecha y hora actual
-- Primera fecha del mes actual
-- �ltima fecha del mes actual

---------------------------------------------------------------------



---------------------------------------------------------------------
-- Task 3
-- 
-- Escriba una declaraci�n SELECT en la tabla Sales.Orders y recupere las columnas orderid, custid y orderdate. Filtre los resultados para incluir solo los pedidos realizados en los �ltimos cinco d�as del mes del pedido.
--

---------------------------------------------------------------------




---------------------------------------------------------------------
-- Task 4
-- 
-- Escriba una declaraci�n SELECT en las tablas Sales.Orders y Sales.OrderDetails y recupere todos los valores distintos para la columna productid. Filtre los resultados para incluir solo los pedidos realizados en las primeras 10 semanas del a�o 2007.
--

---------------------------------------------------------------------
